<?php
 if(!isset($title))
 {
  $title="Tourist agency";
 }
?>
<!DOCTYPE html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex,nofollow,noimageindex,nosnippet,noarchive,notranslate">
  <meta name="author" content="Zeljko Rasovic">
  <meta name="description" content="Tourist agency">
  <meta name="keywords" content="Tourist agency">
  <title><?php echo $title;?></title>
  <link rel="stylesheet" href="../components/default/styles.css">
 </head>
