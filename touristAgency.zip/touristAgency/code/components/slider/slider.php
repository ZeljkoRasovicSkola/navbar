    <div class="slider">
     <div id="sliderImages1">
      <img src="../../img/sliderImages/valensija1.jpg" alt="Valensija 1" id="slide1">
      <img src="../../img/sliderImages/valensija2.jpg" alt="Valensija 2" id="slide2">
      <img src="../../img/sliderImages/valensija3.jpg" alt="Valensija 3" id="slide3">
      <img src="../../img/sliderImages/valensija4.jpg" alt="Valensija 4" id="slide4">
      <img src="../../img/sliderImages/valensija5.jpg" alt="Valensija 5" id="slide5">
      <img src="../../img/sliderImages/valensija2.jpg" alt="Valensija 6" id="slide6">
      <img src="../../img/sliderImages/valensija3.jpg" alt="Valensija 7" id="slide7">
      <img src="../../img/sliderImages/valensija4.jpg" alt="Valensija 8" id="slide8">
     </div>
     <div class="sliderNav">
      <a href="#slide1" onclick="currentSlide(0)" class="imageLink" style="background-image:url('../../img/sliderImages/valensija1.jpg');"></a>
      <a href="#slide2" onclick="currentSlide(1)" class="imageLink" style="background-image:url('../../img/sliderImages/valensija2.jpg');"></a>
      <a href="#slide3" onclick="currentSlide(2)" class="imageLink" style="background-image:url('../../img/sliderImages/valensija3.jpg');"></a>
      <a href="#slide4" onclick="currentSlide(3)" class="imageLink" style="background-image:url('../../img/sliderImages/valensija4.jpg');"></a>
      <a href="#slide5" onclick="currentSlide(4)" class="imageLink" style="background-image:url('../../img/sliderImages/valensija5.jpg');"></a>
      <a href="#slide6" onclick="currentSlide(5)" class="imageLink" style="background-image:url('../../img/sliderImages/valensija2.jpg');"></a>
      <a href="#slide7" onclick="currentSlide(6)" class="imageLink" style="background-image:url('../../img/sliderImages/valensija3.jpg');"></a>
      <a href="#slide8" onclick="currentSlide(7)" class="imageLink" style="background-image:url('../../img/sliderImages/valensija4.jpg');"></a>
     </div>
     <div>
      <button id="leftButton1" onclick="prevSlide()">&larrhk;</button>
      <button id="rightButton1"onclick="nextSlide()">&rarrhk;</button>
     </div>
    </div>
    <script src="../components/slider/slider.js" defer></script>
