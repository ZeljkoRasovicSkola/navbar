const slider=document.getElementById("sliderImages1");
const slides=document.querySelectorAll("#sliderImages1 img");
const dots=document.querySelectorAll(".sliderNav a");
const left=document.getElementById("leftButton1");
const right=document.getElementById("rightButton1");

let slideIndex=0;
let isVisibile=1;

visible();
showSlide(slideIndex);

slider.addEventListener("mouseover",ArrowVisibilityByMouseover);
slider.addEventListener("mouseout",ArrowVisibilityByMouseout);
slider.addEventListener("click",ArrowVisibilityByClick);

function prevSlide()
{
 --slideIndex;
 showSlide(slideIndex);
}
function nextSlide()
{
 ++slideIndex;
 showSlide(slideIndex);
}
function currentSlide(index)
{
 slideIndex=index;
 showSlide(slideIndex);
}
function showSlide(index)
{
 let i=0;
 if(index >= slides.length)
 {
  slideIndex=0;
 }
 if(index < 0)
 {
  slideIndex=slides.length-1;
 }
 for(i=0;i<dots.length;++i)
 {
  dots[i].style.removeProperty("opacity"); ;
 }
 dots[slideIndex].style.opacity=1;
 dots[slideIndex].click();
}

function visible()
{
left.style.visibility="visible";
right.style.visibility="visible";
}

function hide()
{
left.style.visibility="collapse";
right.style.visibility="collapse";
}

function ArrowVisibilityByMouseover()
{
 visible();
 isVisibile=1;
}

function ArrowVisibilityByMouseout()
{
 hide();
 isVisibile=0;
}

function ArrowVisibilityByClick()
{
 if(isVisibile)
 {
  hide();
  isVisibile=0;
 }
 else
 {
  visible();
  isVisibile=1;
 }
}
