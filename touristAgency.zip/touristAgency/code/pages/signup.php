<?php
 $title="Sign up page";
 require '../components/head/head.php';
?>
 <body>
  <?php require '../components/nav/nav.php';?>
  <main>
   <?php require '../components/signup/signup.php';?>
  </main>
 </body>
</html>
