<?php
 $title="Home page";
 require '../components/head/head.php';
?>
 <body>
 <?php require '../components/nav/nav.php';?>
  <main>
  </main>
 </body>
</html>
