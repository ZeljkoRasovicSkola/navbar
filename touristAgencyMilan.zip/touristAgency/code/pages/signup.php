<?php
 $title="Sign up page";
 $signup=1;
 require '../components/head/head.php';
?>
 <body>
  <?php require '../components/nav/nav.php';?>
  <main>
   <?php require '../components/signup/signup.php';?>
  </main>
 </body>
</html>
