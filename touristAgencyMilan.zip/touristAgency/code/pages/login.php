<?php
 $title="Login page";
 $login=1;
 require '../components/head/head.php';
?>
 <body>
  <?php require '../components/nav/nav.php';?>
  <main>
   <?php require '../components/login/login.php';?>
  </main>
 </body>
</html>
