<?php
 if(!isset($title))
 {
  $title="Tourist agency";
 }
 if(!isset($slider))
 {
  $slider=0;
 }
 if(!isset($login))
 {
  $login=0;
 }
 if(!isset($signup))
 {
  $signup=0;
 }
?>
<!DOCTYPE html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex,nofollow,noimageindex,nosnippet,noarchive,notranslate">
  <meta name="author" content="Zeljko Rasovic">
  <meta name="description" content="Tourist agency">
  <meta name="keywords" content="Tourist agency">
  <title><?php echo $title;?></title>
  <link rel="stylesheet" href="../components/nav/nav.css">
  <?php
   if($slider)
   {
    echo'<link rel="stylesheet" href="../components/slider/slider.css">';
   }
   if($login)
   {
    echo'<link rel="stylesheet" href="../components/login/login.css">';
   }
   if($signup)
   {
    echo'<link rel="stylesheet" href="../components/signup/signup.css">';
   }
  ?>
 </head>
