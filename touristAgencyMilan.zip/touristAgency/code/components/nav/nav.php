  <header class="header navBg navFlex">
   <div class="navFlexLeft">
    <a href="index.php" id="logo"><img src="../../img/logos/logo.png" alt="Logo" width="90px" height="40px"></a>
    <a href="index.php" id="logoText"><h2>Tourist agency</h2></a>
   </div>
   <div class="navFlexCenter">
    <form method="GET" action="searchHandler.php" id="navSearchBar">
     <input type="search" placeholder="Search" name="search" id="navSearchBox">
     <input type="reset" value="&#10060;" id="navResetButton">
     <input type="submit" value="&#128269;" id="navSearchButton">
   </form>
   </div>
   <div class="navFlexRight">
    <label for="ham" id="hamMenu"><input type="checkbox" id="ham"></label>
    <nav id=dropdown>
     <form method="GET" action="" id="searchBarHam">
      <input type="search" placeholder="Search" name="search" id="searchBoxHam">
      <input type="reset" value="&#10060;" id="resetButtonHam">
      <input type="submit" value="&#128269;" id="searchButtonHam">
     </form>
     <a href="login.php">Login</a>
     <a href="login.php">Login</a>
     <a href="login.php">Login</a>
     <a href="signup.php">Sign up</a>
    </nav>
   </div>
  </header>
