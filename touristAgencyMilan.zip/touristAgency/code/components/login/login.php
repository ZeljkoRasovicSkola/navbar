   <section class="bg flexCenter">
    <div class="border">
     <div class="flexCenter">
      <h2>Login</h2>
     </div>
     <form method="POST" action="../components/login/loginHandler.php">
      <label for="Email">Email:</label>
      <br>
      <input type="email" name="email" placeholder="Enter your email" required id="Email" class="input">
      <br>
      <br>
      <label for="Password">Password:</label>
      <br>
      <a href="#" class="small">Forgot a password?</a>
      <br>
      <input type="password" name="password" placeholder="Enter your password" required id="Password" class="input">
      <br>
      <br>
      <br>
      <div class="flexCenter">
       <input type="submit" name="submit" value="Login" class="button">
      </div>
      <br>
     </form>
    </div>
   </section>
