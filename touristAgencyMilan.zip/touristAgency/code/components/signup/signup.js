const customSelect=document.querySelector('.customSelect');
const customSelectSelectedItem=document.querySelector('.customSelectSelectedItem');
const selectValue=document.querySelector('#selectValue');
const customSelectDropDown=document.querySelector('.customSelectDropDown');
const customSelectSearch=document.querySelector('.customSelectSearch');
const customSelectItems=document.querySelectorAll('.customSelectItems .customSelectItem');

customSelectItems.forEach(function(customSelectItemSingle)
{
 customSelectItemSingle.addEventListener('click',function()
 {
  customSelectSelectedItem.value=this.textContent;
 })
})

customSelectSearch.addEventListener('keyup',function()
{
 var i=0,filter,textValue;
 filter=customSelectSearch.value.toUpperCase();
 
 for(i=0;i<customSelectItems.length;++i)
 {
  textValue=customSelectItems[i].textContent;
  if(textValue.toUpperCase().indexOf(filter) > -1)
  {
   customSelectItems[i].style.display='block';
  }
  else
  {
   customSelectItems[i].style.display='none';
  }
 }
})

function switchInput()
{
 if(document.getElementById('selectTypeBirthDate').checked)
 {
  document.getElementById('BirthdateDateLabel').style.display='block';
  document.getElementById('BirthdateTextLabel').style.display='none';
  document.getElementById('BirthdateDate').style.display='block';
  document.getElementById('BirthdateText').style.display='none';
 }
 else if(document.getElementById('inputTextTypeBirthDate').checked)
 {
  document.getElementById('BirthdateDateLabel').style.display='none';
  document.getElementById('BirthdateTextLabel').style.display='block';
  document.getElementById('BirthdateDate').style.display='none';
  document.getElementById('BirthdateText').style.display='block';
 }
 if(document.getElementById('selectTypeCountry').checked)
 {
  document.getElementById('CountrySelectLabel').style.display='block';
  document.getElementById('CountryTextLabel').style.display='none';
  document.getElementById('CountrySelect').style.display='block';
  document.getElementById('CountryText').style.display='none';
  document.getElementById('CountryCodeLabel').style.display='none';
  document.getElementById('CountryCodeText').style.display='none';
 }
 else if(document.getElementById('inputTextTypeCountry').checked)
 {
  document.getElementById('CountrySelectLabel').style.display='none';
  document.getElementById('CountryTextLabel').style.display='block';
  document.getElementById('CountrySelect').style.display='none';
  document.getElementById('CountryText').style.display='block';
  document.getElementById('CountryCodeLabel').style.display='block';
  document.getElementById('CountryCodeText').style.display='block';
 }
 if(document.getElementById('selectTypeCity').checked)
 {
  document.getElementById('CitySelectLabel').style.display='block';
  document.getElementById('CityTextLabel').style.display='none';
  document.getElementById('CitySelect').style.display='block';
  document.getElementById('CityText').style.display='none';
  document.getElementById('PostalCodeLabel').style.display='none';
  document.getElementById('PostalCodeText').style.display='none';
 }
 else if(document.getElementById('inputTextTypeCity').checked)
 {
  document.getElementById('CitySelectLabel').style.display='none';
  document.getElementById('CityTextLabel').style.display='block';
  document.getElementById('CitySelect').style.display='none';
  document.getElementById('CityText').style.display='block';
  document.getElementById('PostalCodeLabel').style.display='block';
  document.getElementById('PostalCodeText').style.display='inline';
 }
 if(document.getElementById('selectTypePhone').checked)
 {
  document.getElementById('CountryCode').style.display='block';
  document.getElementById('PhoneTextPart').style.display='block';
  document.getElementById('PhoneTextPart').style.width='65%';
 }
 else if(document.getElementById('inputTextTypePhone').checked)
 {
  document.getElementById('CountryCode').style.display='none';
  document.getElementById('PhoneTextPart').style.display='block';
  document.getElementById('PhoneTextPart').style.width='95%';
 }
}
